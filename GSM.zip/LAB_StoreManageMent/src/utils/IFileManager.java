package utils;

import entities.Product;
import java.util.List;

public interface IFileManager {
    void saveToFile(String path, Product data);

    List<String> loadData(String path);

}
